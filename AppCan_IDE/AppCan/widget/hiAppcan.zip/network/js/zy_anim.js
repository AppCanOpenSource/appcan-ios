	function reset(a,b)
	{
			a.style.webkitTransitionProperty="-webkit-transform";	
			b.style.webkitTransitionProperty="-webkit-transform";	
			a.style.webkitTransitionDuration = '500ms';
        	b.style.webkitTransitionDuration = '500ms';
	}
	function zy_anim_slide(p1,p2,t,cb)
	{
		var a=document.getElementById(p1);
		var b=document.getElementById(p2);
		function anim_move()
		{	
			reset(a,b);
			switch(t)
			{
				case "slide_left":
				a.style.webkitTransform = "translate(-100%,0px)";	
        		b.style.webkitTransform = "translate(0%,0px)";
        		break;
        		case "slide_right":
	        	a.style.webkitTransform = "translate(100%,0px)";
    	    	b.style.webkitTransform = "translate(0%,0px)";
    	    	break;
        		case "slide_up":
        		b.style.webkitTransform = "translate(0px,0%)";
        		break;
        		case "slide_down":
        		a.style.webkitTransform = "translate(0px,100%)";
        		break;
			}
		}
		switch(t)
		{
			case "slide_left":
				a.style.webkitTransform="translate(0px,0px)";
				b.style.webkitTransform="translate(100%,0px)";
				break;
			case "slide_right":
				a.style.webkitTransform="translate(0px,0px)";
				b.style.webkitTransform="translate(-100%,0px)";
				break;
			case "slide_up":
				a.style.zindex=0;
				b.style.zindex=3;
				b.style.webkitTransform="translate(0px,100%)";
				break;
			case "slide_down":
				b.style.zindex=0;
				break;
		}
		b.style.display="block";
		setTimeout(anim_move,1);
	}
