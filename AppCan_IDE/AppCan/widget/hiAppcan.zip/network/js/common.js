﻿var params = {};
function parseParam(){
	var loc = String(document.location);
	var pieces = loc.substr(loc.indexOf('?') + 1).split('&');
	params.keys = [];
	for (var i = 0; i < pieces.length; i += 1) {
		var keyVal = pieces[i].split('=');
		params[keyVal[0]] = decodeURIComponent(keyVal[1]);
		params.keys.push(keyVal[0]);
	}
}

 function time(){
	var date = new Date();
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	var d = date.getDate();
	var h = date.getHours();
	var mm = date.getMinutes();
	var s = date.getSeconds();
	return "" + y + "年" + m + "月" + d + "日" + "  " + h + "时" + mm +"分" + s +"秒";
}
 function timeAndDate(){
	var date = new Date();
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	if(m < 10) m = '0'+m;
	var d = date.getDate();
	if(d < 10) d = '0'+d;
	var h = date.getHours();
	if(h < 10) h = '0'+h;
	var mm = date.getMinutes();
	if(mm < 10) mm = '0'+mm;
	var s = date.getSeconds();
	if(s < 10) s = '0'+s;
	var arr  = new Array();
	var t = ''+h+':'+mm;
	var d = ''+y+'-'+m+'-'+d;
	arr[0] = t;
	arr[1] = d;
	return arr;
}