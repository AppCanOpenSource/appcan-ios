 function zy_for(e,cb)
    {
    	var ch = e.currentTarget.previousElementSibling;
    	if(ch.nodeName == "INPUT")
    	{
    		if(ch.type=="checkbox")
    			ch.checked=!ch.checked;
    		if(ch.type=="radio" && !ch.checked)
    			ch.checked="checked";
    			
    	}
    	if(cb)
    		cb(e,ch.checked);
    }
    function zy_fix(header,footer,run,cb)
    {
        window.uexOnload = function(type){	
         	switch(type)
      		{
      			case 0:
      			{
    	  			if(header)
    	  			{
    	  				
    	  				var ho = document.getElementById(header);
    	  				ho.style.fontSize=window.getComputedStyle(ho,null).fontSize;
    	  				if(ho){
    	  					uexWindow.openSlibing("1", "2", "head.html", ho.outerHTML, "", ho.offsetHeight);
    	  				}
    	  					
    	  			}
    	  			if(footer) 			
    	  			{
    	  				var fo = document.getElementById(footer);
    	  				fo.style.fontSize=window.getComputedStyle(fo,null).fontSize;
    	  				if(fo){
    	  					uexWindow.openSlibing("2", "2", "head.html", fo.outerHTML, "", fo.offsetHeight);
    	  				}
    	  					
    	  			}
    	  			if(cb)
    	  				cb();
      			}
      			break;
      			case 1:
      				var ao=document.getElementById(header);
      				if(ao)
      				{
      					uexWindow.showSlibing("1");
      				}
      				break;
      			case 2:
      				var bo=document.getElementById(footer);
      				if(bo)
      				{
       					uexWindow.showSlibing("2");
      				}
      				break;
          	}
      	};
      	window.uexOnshow=function(type)
	      	{
	      		switch(type)
	      		{
					case 1:
						var ao=document.getElementById(header);
						if(ao)
						{
							ao.style.display="none";
						}
						break;
					case 2:
						var bo=document.getElementById(footer);
						if(bo)
						{
							bo.style.display="none";
						}
						break;
	      		}
	      	};
      	if(run)
		{
      		window.uexOnload(0);
		}
    }

