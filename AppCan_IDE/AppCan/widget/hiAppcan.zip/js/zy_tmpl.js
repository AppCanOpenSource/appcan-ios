var zy_tmpl = function(t,dd,cb){
	var r = "";
	var l = 1;	
	var _f = function(d,c,k1,k2){
		var q = c.match(/(first:|last:)(\"|\'*)(.*)(\"|\'*)/);
		if(!q) return;
		if(q[1]==k1){
			if(q[2]=='\"'||q[2]=='\''){
				return q[3];
			}
			else
				return d[q[3]];
		}
		else if(q[1]==k2 && l>1)
			return "";
	}
	var t_f = function(d,i){
			return t.replace( /\$\{([^\}]*)\}/g,function(m,c){
			if(c.match(/index:/)){
				return i;
			}
			if(i==0){
				var s=_f(d,c,"first:","last:");
				if(s) return s;
			}
			if(i==(l-1)){
				var s= _f(d,c,"last:","first:");
				if(s) return s;
			}
			return d[c]||"";
		});
	}
	if(typeof dd ==="object"){
		if(Object.prototype.toString.apply(dd)==="[object Array]"){
			l = dd.length;
			for(var i = 0; i<l;i++){
				if(cb) cb(t_f(dd[i],i));
				else
					r+=t_f(dd[i],i);
			}
		}
		else{
			if(cb) cb(t_f(dd,0));
			else
			r = t_f(dd,0);
		}
	}
	return r;	
}
function zy_tmpl_c(t,i)
{
	var r="";
	for(var it in i)
	{
		r+=zy_tmpl(t,i[it]);
	}
	return r;
}